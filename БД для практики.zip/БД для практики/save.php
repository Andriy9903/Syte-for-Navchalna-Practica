<?php
// Дозволяємо доступ (виправляє CORB та помилки запитів)
header('Content-Type: text/plain; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$type = $_GET['type'] ?? '';
$action = $_GET['action'] ?? '';
$file = ($type === 'users') ? 'users.txt' : 'base.txt';

// Створюємо файли, якщо їх немає, щоб PHP не видавав помилку 500
if (!file_exists($file)) {
    file_put_contents($file, "");
}

// ОБРОБКА GET (Читання)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo file_get_contents($file);
    exit;
}

// ОБРОБКА POST (Запис)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = file_get_contents('php://input');
    
    if ($action === 'overwrite') {
        // Повне перезаписування (для видалення)
        file_put_contents($file, $content);
    } else {
        // Додавання нового рядка (реєстрація або новий запис)
        // Додаємо перенос рядка, якщо файл не порожній
        $prefix = (filesize($file) > 0) ? PHP_EOL : "";
        file_put_contents($file, $prefix . $content, FILE_APPEND);
    }
    echo "success";
    exit;
}
?>