document.addEventListener('DOMContentLoaded', () => {
 
  /* -----------------------------------------------
     1. Активне посилання в навігації
  ----------------------------------------------- */
  const navLinks = document.querySelectorAll('.nav-btn');
 
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      // Зняти активний клас з усіх кнопок
      navLinks.forEach(l => l.classList.remove('nav-btn--active'));
      // Додати активний клас на клікнуту
      link.classList.add('nav-btn--active');
    });
  });
 
  /* -----------------------------------------------
     2. Плавна поява карток при прокрутці (Intersection Observer)
  ----------------------------------------------- */
  const cards = document.querySelectorAll('.team-card');
 
  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.12
  };
 
  const cardObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('card--visible');
        cardObserver.unobserve(entry.target);
      }
    });
  }, observerOptions);
 
  // Додаємо початковий стан «невидимо» через JS (щоб без JS сторінка виглядала нормально)
  cards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.transition = `opacity 0.5s ease ${index * 0.07}s, transform 0.5s ease ${index * 0.07}s`;
    cardObserver.observe(card);
  });
 
  // Коли картка стає видимою — анімуємо появу
  const styleEl = document.createElement('style');
  styleEl.textContent = `
    .card--visible {
      opacity: 1 !important;
      transform: translateY(0) !important;
    }
  `;
  document.head.appendChild(styleEl);
 
  /* -----------------------------------------------
     3. Кнопка «Пошук» — фокус на полі пошуку (якщо є)
  ----------------------------------------------- */
  const searchBtn = document.querySelector('.nav-btn--search');
  if (searchBtn) {
    searchBtn.addEventListener('click', (e) => {
      e.preventDefault();
      // Якщо на сторінці є поле пошуку — сфокусуватись на ньому
      const searchInput = document.querySelector('input[type="search"], input[placeholder*="пошук"], input[placeholder*="Пошук"]');
      if (searchInput) {
        searchInput.focus();
      }
    });
  }
 
  /* -----------------------------------------------
     4. Заглушки для фото: якщо зображення не завантажилось
        — показати кольоровий плейсхолдер
  ----------------------------------------------- */
  const photoImgs = document.querySelectorAll('.team-card__photo img');
  photoImgs.forEach(img => {
    img.addEventListener('error', () => {
      img.style.display = 'none';
    });
    img.addEventListener('load', () => {
      // Якщо фото завантажилось — сховати плейсхолдер
      const placeholder = img.nextElementSibling;
      if (placeholder) {
        placeholder.style.display = 'none';
      }
    });
  });
 
  /* -----------------------------------------------
     5. Масштабування (zoom) — сторінка гнучко тягнеться
        завдяки clamp() та % в CSS; JS лише додає обробку
        події resize для перевірки орієнтації
  ----------------------------------------------- */
  function handleResize() {
    const vw = window.innerWidth;
    // При дуже маленькому вікні ховаємо деякі пункти меню (опціонально)
    const navMenu = document.querySelector('.navbar__menu');
    if (!navMenu) return;
 
    if (vw < 400) {
      navMenu.style.gap = '0.25rem';
    } else {
      navMenu.style.gap = '';
    }
  }
 
  window.addEventListener('resize', handleResize);
  handleResize(); // Запуск при старті
 
});